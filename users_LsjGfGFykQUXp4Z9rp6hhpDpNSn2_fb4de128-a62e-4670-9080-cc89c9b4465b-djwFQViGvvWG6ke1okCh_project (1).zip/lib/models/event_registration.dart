import 'dart:convert';

class EventRegistration {
  final String id;
  final String eventId;
  final String attendeeThixId;
  final int tickets;
  /// Code unique à présenter à l'entrée (code-barres / scan).
  final String ticketCode;
  final String? note;
  final DateTime createdAt;
  final DateTime updatedAt;

  const EventRegistration({
    required this.id,
    required this.eventId,
    required this.attendeeThixId,
    required this.tickets,
    required this.ticketCode,
    required this.note,
    required this.createdAt,
    required this.updatedAt,
  });

  EventRegistration copyWith({
    String? id,
    String? eventId,
    String? attendeeThixId,
    int? tickets,
    String? ticketCode,
    String? note,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return EventRegistration(
      id: id ?? this.id,
      eventId: eventId ?? this.eventId,
      attendeeThixId: attendeeThixId ?? this.attendeeThixId,
      tickets: tickets ?? this.tickets,
      ticketCode: ticketCode ?? this.ticketCode,
      note: note ?? this.note,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'event_id': eventId,
      'attendee_thix_id': attendeeThixId,
      'tickets': tickets,
      'ticket_code': ticketCode,
      'note': note,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  static EventRegistration fromJson(Map<String, dynamic> json) {
    DateTime parseDate(Object? v) {
      if (v is String) return DateTime.tryParse(v) ?? DateTime.now();
      return DateTime.now();
    }

    final rawNote = (json['note'] ?? '').toString();
    return EventRegistration(
      id: (json['id'] ?? '').toString(),
      eventId: (json['event_id'] ?? '').toString(),
      attendeeThixId: (json['attendee_thix_id'] ?? '').toString(),
      tickets: int.tryParse((json['tickets'] ?? '').toString()) ?? 1,
      ticketCode: (json['ticket_code'] ?? '').toString().trim().isEmpty ? (json['id'] ?? '').toString() : (json['ticket_code'] ?? '').toString(),
      note: rawNote.trim().isEmpty ? null : rawNote,
      createdAt: parseDate(json['created_at']),
      updatedAt: parseDate(json['updated_at']),
    );
  }

  static String encodeList(List<EventRegistration> items) => jsonEncode(items.map((e) => e.toJson()).toList(growable: false));

  static List<EventRegistration> decodeList(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return const [];
    return decoded.whereType<Map>().map((m) => EventRegistration.fromJson(m.cast<String, dynamic>())).toList(growable: false);
  }
}
