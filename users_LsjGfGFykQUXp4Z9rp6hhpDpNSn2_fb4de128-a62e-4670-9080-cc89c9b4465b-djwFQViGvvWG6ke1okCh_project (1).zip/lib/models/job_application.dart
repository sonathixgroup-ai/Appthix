import 'dart:convert';

class JobApplication {
  final String id;
  final String jobId;
  final String applicantThixId;
  final String? message;
  final DateTime createdAt;
  final DateTime updatedAt;

  const JobApplication({
    required this.id,
    required this.jobId,
    required this.applicantThixId,
    required this.message,
    required this.createdAt,
    required this.updatedAt,
  });

  JobApplication copyWith({
    String? id,
    String? jobId,
    String? applicantThixId,
    String? message,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return JobApplication(
      id: id ?? this.id,
      jobId: jobId ?? this.jobId,
      applicantThixId: applicantThixId ?? this.applicantThixId,
      message: message ?? this.message,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'job_id': jobId,
      'applicant_thix_id': applicantThixId,
      'message': message,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  static JobApplication fromJson(Map<String, dynamic> json) {
    DateTime parseDate(Object? v) {
      if (v is String) return DateTime.tryParse(v) ?? DateTime.now();
      return DateTime.now();
    }

    return JobApplication(
      id: (json['id'] ?? '').toString(),
      jobId: (json['job_id'] ?? '').toString(),
      applicantThixId: (json['applicant_thix_id'] ?? '').toString(),
      message: (json['message'] ?? '').toString().trim().isEmpty ? null : (json['message'] ?? '').toString(),
      createdAt: parseDate(json['created_at']),
      updatedAt: parseDate(json['updated_at']),
    );
  }

  static String encodeList(List<JobApplication> items) => jsonEncode(items.map((e) => e.toJson()).toList(growable: false));

  static List<JobApplication> decodeList(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return const [];
    return decoded.whereType<Map>().map((m) => JobApplication.fromJson(m.cast<String, dynamic>())).toList(growable: false);
  }
}
