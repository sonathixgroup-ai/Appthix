import 'dart:convert';

class JobPosting {
  final String id;
  final String title;
  final String company;
  final String location;
  final String salary;
  final String type;
  final String description;
  final List<String> requirements;
  final DateTime createdAt;
  final DateTime updatedAt;

  const JobPosting({
    required this.id,
    required this.title,
    required this.company,
    required this.location,
    required this.salary,
    required this.type,
    required this.description,
    required this.requirements,
    required this.createdAt,
    required this.updatedAt,
  });

  JobPosting copyWith({
    String? id,
    String? title,
    String? company,
    String? location,
    String? salary,
    String? type,
    String? description,
    List<String>? requirements,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return JobPosting(
      id: id ?? this.id,
      title: title ?? this.title,
      company: company ?? this.company,
      location: location ?? this.location,
      salary: salary ?? this.salary,
      type: type ?? this.type,
      description: description ?? this.description,
      requirements: requirements ?? this.requirements,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'company': company,
      'location': location,
      'salary': salary,
      'type': type,
      'description': description,
      'requirements': requirements,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  static JobPosting fromJson(Map<String, dynamic> json) {
    DateTime parseDate(Object? v) {
      if (v is String) return DateTime.tryParse(v) ?? DateTime.now();
      return DateTime.now();
    }

    return JobPosting(
      id: (json['id'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      company: (json['company'] ?? '').toString(),
      location: (json['location'] ?? '').toString(),
      salary: (json['salary'] ?? '').toString(),
      type: (json['type'] ?? '').toString(),
      description: (json['description'] ?? '').toString(),
      requirements: (json['requirements'] is List)
          ? (json['requirements'] as List).map((e) => e.toString()).toList(growable: false)
          : const <String>[],
      createdAt: parseDate(json['created_at']),
      updatedAt: parseDate(json['updated_at']),
    );
  }

  static String encodeList(List<JobPosting> items) => jsonEncode(items.map((e) => e.toJson()).toList(growable: false));

  static List<JobPosting> decodeList(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return const [];
    return decoded.whereType<Map>().map((m) => JobPosting.fromJson(m.cast<String, dynamic>())).toList(growable: false);
  }
}
