import 'dart:convert';

class EventItem {
  final String id;
  final String title;
  final String dateLabel;
  final DateTime startsAt;
  final String location;
  final String price;
  final String category;
  final String attendeesLabel;
  final String description;
  final List<String> highlights;
  /// Local asset path used as hero/cover image.
  /// Example: `assets/images/tech_conference_stage_audience_grayscale_1778649599691.jpg`
  final String? imageAssetPath;
  final DateTime createdAt;
  final DateTime updatedAt;

  const EventItem({
    required this.id,
    required this.title,
    required this.dateLabel,
    required this.startsAt,
    required this.location,
    required this.price,
    required this.category,
    required this.attendeesLabel,
    required this.description,
    required this.highlights,
    required this.imageAssetPath,
    required this.createdAt,
    required this.updatedAt,
  });

  EventItem copyWith({
    String? id,
    String? title,
    String? dateLabel,
    DateTime? startsAt,
    String? location,
    String? price,
    String? category,
    String? attendeesLabel,
    String? description,
    List<String>? highlights,
    String? imageAssetPath,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return EventItem(
      id: id ?? this.id,
      title: title ?? this.title,
      dateLabel: dateLabel ?? this.dateLabel,
      startsAt: startsAt ?? this.startsAt,
      location: location ?? this.location,
      price: price ?? this.price,
      category: category ?? this.category,
      attendeesLabel: attendeesLabel ?? this.attendeesLabel,
      description: description ?? this.description,
      highlights: highlights ?? this.highlights,
      imageAssetPath: imageAssetPath ?? this.imageAssetPath,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'date_label': dateLabel,
      'starts_at': startsAt.toIso8601String(),
      'location': location,
      'price': price,
      'category': category,
      'attendees_label': attendeesLabel,
      'description': description,
      'highlights': highlights,
      'image_asset_path': imageAssetPath,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  static EventItem fromJson(Map<String, dynamic> json) {
    DateTime parseDate(Object? v) {
      if (v is String) return DateTime.tryParse(v) ?? DateTime.now();
      return DateTime.now();
    }

    return EventItem(
      id: (json['id'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      dateLabel: (json['date_label'] ?? '').toString(),
      startsAt: parseDate(json['starts_at']),
      location: (json['location'] ?? '').toString(),
      price: (json['price'] ?? '').toString(),
      category: (json['category'] ?? '').toString(),
      attendeesLabel: (json['attendees_label'] ?? '').toString(),
      description: (json['description'] ?? '').toString(),
      highlights: (json['highlights'] is List)
          ? (json['highlights'] as List).map((e) => e.toString()).toList(growable: false)
          : const <String>[],
      imageAssetPath: (json['image_asset_path'] ?? '').toString().trim().isEmpty ? null : (json['image_asset_path'] ?? '').toString(),
      createdAt: parseDate(json['created_at']),
      updatedAt: parseDate(json['updated_at']),
    );
  }

  static String encodeList(List<EventItem> items) => jsonEncode(items.map((e) => e.toJson()).toList(growable: false));

  static List<EventItem> decodeList(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return const [];
    return decoded.whereType<Map>().map((m) => EventItem.fromJson(m.cast<String, dynamic>())).toList(growable: false);
  }
}
