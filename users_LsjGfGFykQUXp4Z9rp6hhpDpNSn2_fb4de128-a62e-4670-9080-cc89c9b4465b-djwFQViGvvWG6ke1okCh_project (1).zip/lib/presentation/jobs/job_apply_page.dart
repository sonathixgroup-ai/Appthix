import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:thix_id/auth/auth_controller.dart';
import 'package:thix_id/nav.dart';
import 'package:thix_id/services/job_service.dart';
import 'package:thix_id/services/profile_service.dart';
import 'package:thix_id/services/thix_id_service.dart';
import 'package:thix_id/theme.dart';

class JobApplyPage extends StatefulWidget {
  final String jobId;
  const JobApplyPage({super.key, required this.jobId});

  @override
  State<JobApplyPage> createState() => _JobApplyPageState();
}

class _JobApplyPageState extends State<JobApplyPage> {
  final _jobService = JobService();
  final _profileService = ProfileService();
  final _thixCtrl = TextEditingController();
  final _messageCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _thixCtrl.dispose();
    _messageCtrl.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final auth = context.read<AuthController>();
    final thixId = auth.currentUser?.thixId ?? '';
    if (_thixCtrl.text.trim().isEmpty && thixId.trim().isNotEmpty) {
      _thixCtrl.text = thixId;
    }
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _error = null;
      _loading = true;
    });

    try {
      final canonical = ThixIdService.canonicalizeOrNull(_thixCtrl.text);
      if (canonical == null || !ThixIdService.isValid(canonical)) {
        setState(() => _error = 'THIX ID invalide. Exemple: ${ThixIdService.exampleV2}');
        return;
      }

      final profile = await _profileService.fetchPublicProfileByThixId(canonical);
      if (profile == null) {
        setState(() => _error = 'Aucun profil trouvé pour ce THIX ID. Vérifie l’ID ou contacte le support.');
        return;
      }

      await _jobService.submitApplication(jobId: widget.jobId, applicantThixId: canonical, message: _messageCtrl.text);
      if (!mounted) return;
      context.go('/jobs/${widget.jobId}?applied=1');
    } catch (e) {
      debugPrint('JobApplyPage.submit failed err=$e');
      if (!mounted) return;
      setState(() => _error = 'Erreur lors de la candidature. Réessaie.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final me = auth.currentUser;

    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: FutureBuilder(
          future: _jobService.fetchJob(widget.jobId),
          builder: (context, snap) {
            final job = snap.data;
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (job == null) {
              return Padding(
                padding: const EdgeInsets.all(AppSpacing.lg),
                child: Column(
                  children: [
                    _TopBar(jobId: widget.jobId),
                    const Spacer(),
                    Text('Offre introuvable.', style: context.textStyles.titleMedium?.copyWith(color: context.theme.colorScheme.onSurface)),
                    const SizedBox(height: AppSpacing.lg),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: () => context.popOrGo(AppRoutes.jobs),
                        child: const Text('Retour'),
                      ),
                    ),
                    const Spacer(),
                  ],
                ),
              );
            }

            return SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _TopBar(jobId: widget.jobId),
                  const SizedBox(height: AppSpacing.md),
                  Text('Postuler', style: context.textStyles.titleLarge?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w900)),
                  const SizedBox(height: AppSpacing.xs),
                  Text(job.title, style: context.textStyles.titleMedium?.copyWith(color: LightModeColors.secondaryText, fontWeight: FontWeight.w700)),
                  const SizedBox(height: AppSpacing.lg),
                  Container(
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    decoration: BoxDecoration(
                      color: context.theme.colorScheme.surface,
                      borderRadius: BorderRadius.circular(AppRadius.xl),
                      border: Border.all(color: LightModeColors.accent.withValues(alpha: 0.45), width: 1.5),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.verified_user_rounded, color: LightModeColors.success),
                            const SizedBox(width: AppSpacing.sm),
                            Expanded(
                              child: Text('Vérification THIX ID obligatoire', style: context.textStyles.titleSmall?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w800)),
                            ),
                          ],
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        Text(
                          me?.hasRealThixId == true
                              ? 'Nous avons pré-rempli ton THIX ID. Tu peux le modifier si nécessaire.'
                              : 'Entre ton THIX ID (il sera vérifié en base avant envoi).',
                          style: context.textStyles.bodyMedium?.copyWith(color: LightModeColors.secondaryText, height: 1.5),
                        ),
                        const SizedBox(height: AppSpacing.md),
                        TextField(
                          controller: _thixCtrl,
                          textCapitalization: TextCapitalization.characters,
                          decoration: InputDecoration(
                            labelText: 'THIX ID',
                            hintText: ThixIdService.exampleV2,
                            prefixIcon: const Icon(Icons.badge_rounded),
                          ),
                          onChanged: (_) {
                            if (_error != null) setState(() => _error = null);
                          },
                        ),
                        const SizedBox(height: AppSpacing.md),
                        TextField(
                          controller: _messageCtrl,
                          minLines: 3,
                          maxLines: 7,
                          decoration: const InputDecoration(
                            labelText: 'Message (optionnel)',
                            hintText: 'Présente-toi en 2-3 lignes…',
                            prefixIcon: Icon(Icons.chat_bubble_rounded),
                          ),
                        ),
                        if (_error != null) ...[
                          const SizedBox(height: AppSpacing.md),
                          Text(_error!, style: context.textStyles.bodyMedium?.copyWith(color: context.theme.colorScheme.error, fontWeight: FontWeight.w700)),
                        ],
                        const SizedBox(height: AppSpacing.lg),
                        SizedBox(
                          height: 52,
                          child: FilledButton.icon(
                            onPressed: _loading ? null : _submit,
                            icon: _loading
                                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                                : const Icon(Icons.send_rounded),
                            label: Text(_loading ? 'Envoi…' : 'Envoyer ma candidature'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final String jobId;
  const _TopBar({required this.jobId});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          onPressed: () => context.popOrGo('/jobs/$jobId'),
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
        ),
        Expanded(
          child: Text('THIX Apply', style: context.textStyles.titleLarge?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }
}

extension _ThemeX on BuildContext {
  ThemeData get theme => Theme.of(this);
}
