import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:thix_id/nav.dart';
import 'package:thix_id/services/job_service.dart';
import 'package:thix_id/theme.dart';

class JobDetailsPage extends StatefulWidget {
  final String jobId;
  final bool applied;
  const JobDetailsPage({super.key, required this.jobId, this.applied = false});

  @override
  State<JobDetailsPage> createState() => _JobDetailsPageState();
}

class _JobDetailsPageState extends State<JobDetailsPage> {
  final _service = JobService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: FutureBuilder(
          future: _service.fetchJob(widget.jobId),
          builder: (context, snap) {
            final job = snap.data;
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (job == null) {
              return Padding(
                padding: const EdgeInsets.all(AppSpacing.lg),
                child: Column(
                  children: [
                    _TopBar(title: 'Détails'),
                    const SizedBox(height: AppSpacing.xl),
                    Text('Offre introuvable.', style: context.textStyles.titleMedium?.copyWith(color: context.theme.colorScheme.onSurface)),
                    const SizedBox(height: AppSpacing.md),
                    Text('Retournez à la liste et réessayez.', style: context.textStyles.bodyMedium?.copyWith(color: LightModeColors.secondaryText)),
                    const Spacer(),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: () => context.popOrGo(AppRoutes.jobs),
                        child: const Text('Retour'),
                      ),
                    ),
                  ],
                ),
              );
            }

            return CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _TopBar(title: 'Détails'),
                        if (widget.applied) ...[
                          const SizedBox(height: AppSpacing.md),
                          Container(
                            padding: const EdgeInsets.all(AppSpacing.md),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(AppRadius.lg),
                              color: LightModeColors.success.withValues(alpha: 0.10),
                              border: Border.all(color: LightModeColors.success.withValues(alpha: 0.30)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.check_circle_rounded, color: LightModeColors.success),
                                const SizedBox(width: AppSpacing.sm),
                                Expanded(
                                  child: Text(
                                    'Candidature envoyée. Vous recevrez une réponse si votre profil est retenu.',
                                    style: context.textStyles.bodyMedium?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        const SizedBox(height: AppSpacing.lg),
                        Container(
                          padding: const EdgeInsets.all(AppSpacing.lg),
                          decoration: BoxDecoration(
                            color: context.theme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(AppRadius.xl),
                            border: Border.all(color: LightModeColors.accent.withValues(alpha: 0.45), width: 1.5),
                            boxShadow: [
                              BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 24, offset: const Offset(0, 10)),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(AppRadius.md),
                                      color: context.theme.scaffoldBackgroundColor,
                                      border: Border.all(color: context.theme.dividerColor),
                                    ),
                                    alignment: Alignment.center,
                                    child: const Icon(Icons.business_rounded, color: LightModeColors.hint),
                                  ),
                                  const SizedBox(width: AppSpacing.md),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(job.title, style: context.textStyles.titleLarge?.copyWith(fontWeight: FontWeight.w800, color: context.theme.colorScheme.onSurface)),
                                        const SizedBox(height: 2),
                                        Text(job.company, style: context.textStyles.bodyMedium?.copyWith(color: LightModeColors.secondaryText, fontWeight: FontWeight.w600)),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.xs),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(AppRadius.full),
                                      border: Border.all(color: LightModeColors.accent.withValues(alpha: 0.7)),
                                      color: LightModeColors.accent.withValues(alpha: 0.10),
                                    ),
                                    child: Text(job.type, style: context.textStyles.labelMedium?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w700)),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppSpacing.md),
                              Wrap(
                                spacing: AppSpacing.sm,
                                runSpacing: AppSpacing.sm,
                                children: [
                                  _InfoPill(icon: Icons.location_on_rounded, label: job.location),
                                  _InfoPill(icon: Icons.payments_rounded, label: job.salary),
                                  _InfoPill(icon: Icons.verified_user_rounded, label: 'Poste certifié THIX'),
                                ],
                              ),
                              const SizedBox(height: AppSpacing.lg),
                              Text('Description', style: context.textStyles.titleMedium?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w800)),
                              const SizedBox(height: AppSpacing.sm),
                              Text(job.description, style: context.textStyles.bodyMedium?.copyWith(color: LightModeColors.secondaryText, height: 1.5)),
                              const SizedBox(height: AppSpacing.lg),
                              Text('Exigences', style: context.textStyles.titleMedium?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w800)),
                              const SizedBox(height: AppSpacing.sm),
                              ...job.requirements.map((r) => Padding(
                                    padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Padding(
                                          padding: EdgeInsets.only(top: 3),
                                          child: Icon(Icons.check_circle_rounded, size: 18, color: LightModeColors.success),
                                        ),
                                        const SizedBox(width: AppSpacing.sm),
                                        Expanded(child: Text(r, style: context.textStyles.bodyMedium?.copyWith(color: LightModeColors.secondaryText, height: 1.45))),
                                      ],
                                    ),
                                  )),
                            ],
                          ),
                        ),
                        const SizedBox(height: AppSpacing.lg),
                        SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: FilledButton.icon(
                            onPressed: () => context.push('/jobs/${job.id}/apply'),
                            icon: const Icon(Icons.bolt_rounded),
                            label: const Text('Postuler avec THIX ID'),
                          ),
                        ),
                        const SizedBox(height: AppSpacing.md),
                        SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: OutlinedButton.icon(
                            onPressed: () => context.popOrGo(AppRoutes.jobs),
                            icon: const Icon(Icons.arrow_back_rounded),
                            label: const Text('Retour aux offres'),
                          ),
                        ),
                        const SizedBox(height: AppSpacing.xl),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final String title;
  const _TopBar({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          onPressed: () => context.popOrGo(AppRoutes.jobs),
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
        ),
        Expanded(
          child: Text(title, style: context.textStyles.titleLarge?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }
}

class _InfoPill extends StatelessWidget {
  final IconData icon;
  final String label;
  const _InfoPill({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.full),
        border: Border.all(color: context.theme.dividerColor),
        color: context.theme.scaffoldBackgroundColor,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: context.theme.colorScheme.primary),
          const SizedBox(width: AppSpacing.xs),
          Text(label, style: context.textStyles.labelMedium?.copyWith(color: context.theme.colorScheme.onSurface, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

extension _ThemeX on BuildContext {
  ThemeData get theme => Theme.of(this);
}
