import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:thix_id/nav.dart';
import 'package:thix_id/services/job_service.dart';
import '../../theme.dart';

class CategoryChip extends StatelessWidget {
  final String label;
  final bool selected;

  const CategoryChip({
    super.key,
    required this.label,
    required this.selected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: AppSpacing.sm),
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
      decoration: BoxDecoration(
        color: selected ? context.theme.colorScheme.primary : context.theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(AppRadius.full),
        border: Border.all(
          color: selected ? context.theme.colorScheme.primary : context.theme.dividerColor,
        ),
        boxShadow: selected
            ? [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 6,
                  offset: const Offset(0, 4),
                )
              ]
            : [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 3,
                  offset: const Offset(0, 1),
                )
              ],
      ),
      child: Text(
        label,
        style: context.textStyles.labelMedium?.copyWith(
          color: selected ? Colors.white : LightModeColors.secondaryText,
          fontWeight: selected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }
}

class JobCard extends StatelessWidget {
  final String title;
  final String company;
  final String location;
  final String salary;
  final String type;
  final String posted;
  final String logoDesc;
  final VoidCallback onDetails;

  const JobCard({
    super.key,
    required this.title,
    required this.company,
    required this.location,
    required this.salary,
    required this.type,
    required this.posted,
    required this.logoDesc,
    required this.onDetails,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.lg),
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: context.theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: LightModeColors.accent, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 15,
            offset: const Offset(0, 10),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: context.theme.scaffoldBackgroundColor,
                  borderRadius: BorderRadius.circular(AppRadius.md),
                  border: Border.all(color: context.theme.dividerColor),
                ),
                alignment: Alignment.center,
                child: const Icon(Icons.business, color: LightModeColors.hint),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xs),
                decoration: BoxDecoration(
                  color: const Color(0xFFF9C74F).withValues(alpha: 0.13),
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                  border: Border.all(color: LightModeColors.accent),
                ),
                child: Text(
                  type,
                  style: context.textStyles.labelSmall?.copyWith(
                    color: context.theme.colorScheme.onSurface,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: context.textStyles.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: context.theme.colorScheme.onSurface,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: AppSpacing.xs),
              const Icon(Icons.verified_rounded, size: 16, color: LightModeColors.accent),
            ],
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            company,
            style: context.textStyles.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: LightModeColors.secondaryText,
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Row(
            children: [
              const Icon(Icons.location_on_rounded, size: 14, color: LightModeColors.hint),
              const SizedBox(width: AppSpacing.xs),
              Text(
                location,
                style: context.textStyles.bodySmall?.copyWith(
                  color: LightModeColors.secondaryText,
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              const Icon(Icons.payments_rounded, size: 14, color: LightModeColors.success),
              const SizedBox(width: AppSpacing.xs),
              Text(
                salary,
                style: context.textStyles.bodySmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: LightModeColors.success,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Divider(color: context.theme.dividerColor, thickness: 1),
          const SizedBox(height: AppSpacing.sm),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Publié",
                    style: context.textStyles.labelSmall?.copyWith(
                      color: LightModeColors.hint,
                    ),
                  ),
                  Text(
                    posted,
                    style: context.textStyles.bodySmall?.copyWith(
                      color: LightModeColors.secondaryText,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.md),
                decoration: BoxDecoration(
                  color: LightModeColors.accent,
                  borderRadius: BorderRadius.circular(AppRadius.md),
                  border: Border.all(color: const Color(0xFFD4AF37)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 6,
                      offset: const Offset(0, 4),
                    )
                  ],
                ),
                child: GestureDetector(
                  onTap: onDetails,
                  child: Row(
                    children: [
                      const Icon(Icons.visibility_rounded, color: Color(0xFF0A2F5C), size: 16),
                      const SizedBox(width: AppSpacing.sm),
                      Text(
                        "Détails",
                        style: context.textStyles.labelLarge?.copyWith(
                          color: const Color(0xFF0A2F5C),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class JobsPage extends StatelessWidget {
  const JobsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final service = JobService();
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    decoration: BoxDecoration(
                      color: context.theme.colorScheme.primary,
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(AppRadius.xl),
                        bottomRight: Radius.circular(AppRadius.xl),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.15),
                          blurRadius: 25,
                          offset: const Offset(0, 10),
                        )
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(AppRadius.md),
                              ),
                              alignment: Alignment.center,
                              child: IconButton(
                                icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
                                onPressed: () => context.popOrGo(AppRoutes.home),
                              ),
                            ),
                            Text(
                              "Emplois THIX ID",
                              style: context.textStyles.titleLarge?.copyWith(
                                color: Colors.white,
                              ),
                            ),
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(AppRadius.md),
                              ),
                              alignment: Alignment.center,
                              child: IconButton(
                                icon: const Icon(Icons.tune_rounded, color: Colors.white, size: 20),
                                onPressed: () {},
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: AppSpacing.md),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.xs),
                          decoration: BoxDecoration(
                            color: context.theme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(AppRadius.lg),
                            border: Border.all(color: context.theme.dividerColor),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.1),
                                blurRadius: 6,
                                offset: const Offset(0, 4),
                              )
                            ],
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.search_rounded, color: LightModeColors.hint, size: 24),
                              const SizedBox(width: AppSpacing.md),
                              Expanded(
                                child: TextField(
                                  decoration: InputDecoration(
                                    hintText: "Rechercher un emploi...",
                                    hintStyle: context.textStyles.bodyMedium?.copyWith(color: LightModeColors.hint),
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
                                decoration: BoxDecoration(
                                  color: LightModeColors.accent,
                                  borderRadius: BorderRadius.circular(AppRadius.md),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.05),
                                      blurRadius: 3,
                                      offset: const Offset(0, 1),
                                    )
                                  ],
                                ),
                                child: const Icon(Icons.filter_list_rounded, color: Color(0xFF0A2F5C), size: 20),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.lg),
                    padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.lg),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFFF9C74F), Color(0xFFEAB308), Color(0xFFD4AF37)],
                      ),
                      borderRadius: BorderRadius.circular(AppRadius.lg),
                      border: Border.all(color: const Color(0xFFB8860B), width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.2),
                          blurRadius: 25,
                          offset: const Offset(0, 10),
                        )
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: const Color(0xFF0A3D62).withValues(alpha: 0.13),
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFF0A3D62).withValues(alpha: 0.26)),
                          ),
                          alignment: Alignment.center,
                          child: Icon(Icons.auto_awesome_rounded, color: context.theme.colorScheme.primary, size: 28),
                        ),
                        const SizedBox(width: AppSpacing.md),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "1,248 Postes Certifiés",
                                style: context.textStyles.titleMedium?.copyWith(
                                  color: const Color(0xFF0A2F5C),
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              const SizedBox(height: AppSpacing.xs),
                              Text(
                                "Accès exclusif aux membres THIX ID",
                                style: context.textStyles.bodySmall?.copyWith(
                                  color: const Color(0xFF0A2F5C),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.workspace_premium_rounded, color: context.theme.colorScheme.primary, size: 32),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: AppSpacing.md, left: AppSpacing.md, right: AppSpacing.md),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                          child: Text(
                            "Secteurs d'Activité",
                            style: context.textStyles.titleMedium?.copyWith(
                              color: context.theme.colorScheme.onSurface,
                            ),
                          ),
                        ),
                        const SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          padding: EdgeInsets.only(bottom: AppSpacing.sm),
                          child: Row(
                            children: [
                              CategoryChip(label: "Tous les postes", selected: true),
                              CategoryChip(label: "Mines & Énergie", selected: false),
                              CategoryChip(label: "Technologies", selected: false),
                              CategoryChip(label: "Gouvernement", selected: false),
                              CategoryChip(label: "Banque & Finance", selected: false),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Offres à la une",
                                  style: context.textStyles.titleLarge?.copyWith(
                                    color: context.theme.colorScheme.onSurface,
                                  ),
                                ),
                                Text(
                                  "Basé sur votre profil THIX ID",
                                  style: context.textStyles.bodySmall?.copyWith(
                                    color: LightModeColors.secondaryText,
                                  ),
                                ),
                              ],
                            ),
                            Text(
                              "Voir tout",
                              style: context.textStyles.labelLarge?.copyWith(
                                color: context.theme.colorScheme.primary,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: AppSpacing.lg),
                        FutureBuilder(
                          future: service.listJobs(),
                          builder: (context, snap) {
                            final jobs = snap.data ?? const [];
                            if (snap.connectionState != ConnectionState.done) {
                              return const Padding(
                                padding: EdgeInsets.only(top: AppSpacing.xl),
                                child: Center(child: CircularProgressIndicator()),
                              );
                            }
                            if (jobs.isEmpty) {
                              return Padding(
                                padding: const EdgeInsets.only(top: AppSpacing.xl),
                                child: Text('Aucune offre disponible.', style: context.textStyles.bodyMedium?.copyWith(color: LightModeColors.secondaryText)),
                              );
                            }

                            String postedLabel(DateTime createdAt) {
                              final d = DateTime.now().difference(createdAt);
                              if (d.inMinutes < 60) return 'Il y a ${d.inMinutes} min';
                              if (d.inHours < 24) return 'Il y a ${d.inHours}h';
                              return 'Il y a ${d.inDays}j';
                            }

                            return Column(
                              children: jobs
                                  .map(
                                    (j) => JobCard(
                                      title: j.title,
                                      company: j.company,
                                      location: j.location,
                                      salary: j.salary,
                                      type: j.type,
                                      posted: postedLabel(j.createdAt),
                                      logoDesc: 'logo',
                                      onDetails: () => context.push('/jobs/${j.id}'),
                                    ),
                                  )
                                  .toList(growable: false),
                            );
                          },
                        ),
                        const SizedBox(height: 80),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.notifications_active_rounded, color: Color(0xFF0A2F5C)),
        label: Text("Créer une alerte", style: context.textStyles.labelLarge?.copyWith(color: const Color(0xFF0A2F5C))),
        backgroundColor: LightModeColors.accent,
      ),
    );
  }
}

extension ThemeHelper on BuildContext {
  ThemeData get theme => Theme.of(this);
}